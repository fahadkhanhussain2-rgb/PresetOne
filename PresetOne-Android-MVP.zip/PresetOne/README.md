# PresetOne

A native Android MVP for one-tap photo editing.

## Current MVP
- Android photo picker
- Preset engine
- One-tap presets
- AI Auto (local automatic adjustment)
- Exposure/contrast/saturation/warmth controls
- Before/after
- Reset
- JPEG export to Pictures/PresetOne

## Build
Open the project in Android Studio and sync Gradle, then build the APK.

The environment used to generate this project does not include the Android SDK/Gradle toolchain, so an APK could not be compiled in this session.

Official Android build documentation:
https://developer.android.com/build
