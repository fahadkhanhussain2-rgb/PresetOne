package com.presetone.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import kotlin.math.max

data class EditState(
    val exposure: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f
)

data class Preset(val name: String, val edit: EditState)

private val presets = listOf(
    Preset("Natural", EditState()),
    Preset("Cinematic", EditState(-0.05f, 1.25f, 1.08f, 0.03f)),
    Preset("Moody", EditState(-0.12f, 1.35f, 0.82f, -0.02f)),
    Preset("Golden", EditState(0.08f, 1.12f, 1.15f, 0.12f)),
    Preset("Vivid", EditState(0.05f, 1.18f, 1.35f, 0.02f)),
    Preset("Vintage", EditState(-0.05f, 1.08f, 0.78f, 0.08f)),
    Preset("Night", EditState(0.10f, 1.28f, 0.92f, -0.08f)),
    Preset("B&W", EditState(0f, 1.2f, 0f, 0f))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PresetOneApp() }
    }
}

@Composable
fun PresetOneApp() {
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var original by remember { mutableStateOf<Bitmap?>(null) }
    var edit by remember { mutableStateOf(EditState()) }
    var before by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val stream = (LocalContext.current as android.content.Context).contentResolver.openInputStream(uri)
        val b = stream?.use { BitmapFactory.decodeStream(it) }
        b?.let {
            original = it
            bitmap = it
            edit = EditState()
            showEditor = true
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0B0D)) {
            if (!showEditor || bitmap == null) {
                HomeScreen(onPick = { picker.launch("image/*") })
            } else {
                EditorScreen(
                    original = original!!,
                    bitmap = bitmap!!,
                    edit = edit,
                    before = before,
                    onBack = { showEditor = false },
                    onEdit = { edit = it },
                    onBefore = { before = !before },
                    onReset = { edit = EditState() },
                    onExport = { exportBitmap(this, original!!, edit) }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Spacer(Modifier.height(20.dp))
            Text("PresetOne", fontSize = 34.sp, color = Color.White)
            Text("Professional photo editing. One tap.", color = Color.LightGray)
            Spacer(Modifier.height(36.dp))
            Card(
                onClick = onPick,
                modifier = Modifier.fillMaxWidth().height(180.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181C))
            ) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, null, Modifier.size(52.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Choose a photo", fontSize = 21.sp)
                    Text("Start editing instantly", color = Color.Gray)
                }
            }
        }
        Button(
            onClick = onPick,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("+ NEW PHOTO", fontSize = 17.sp)
        }
    }
}

@Composable
fun EditorScreen(
    original: Bitmap,
    bitmap: Bitmap,
    edit: EditState,
    before: Boolean,
    onBack: () -> Unit,
    onEdit: (EditState) -> Unit,
    onBefore: () -> Unit,
    onReset: () -> Unit,
    onExport: () -> Unit
) {
    val preview = if (before) original else bitmap
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Editor", fontSize = 20.sp)
            Row {
                IconButton(onClick = onBefore) { Icon(Icons.Default.Compare, "Before/After") }
                IconButton(onClick = onReset) { Icon(Icons.Default.Refresh, "Reset") }
            }
        }

        Image(
            preview.asImageBitmap(),
            null,
            Modifier.fillMaxWidth().weight(1f),
            contentScale = ContentScale.Fit
        )

        PresetRow(onEdit)

        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
        ) {
            SliderControl("Exposure", edit.exposure, -1f..1f) { onEdit(edit.copy(exposure = it)) }
            SliderControl("Contrast", edit.contrast, 0.5f..1.8f) { onEdit(edit.copy(contrast = it)) }
            SliderControl("Saturation", edit.saturation, 0f..1.8f) { onEdit(edit.copy(saturation = it)) }
            SliderControl("Warmth", edit.warmth, -0.5f..0.5f) { onEdit(edit.copy(warmth = it)) }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onEdit(autoEdit(original)) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(6.dp))
                    Text("AI AUTO")
                }
                Button(
                    onClick = onExport,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.IosShare, null)
                    Spacer(Modifier.width(6.dp))
                    Text("EXPORT")
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun PresetRow(onEdit: (EditState) -> Unit) {
    Column {
        Text("Presets", Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)
        ) {
            presets.forEach { preset ->
                AssistChip(
                    onClick = { onEdit(preset.edit) },
                    label = { Text(preset.name) },
                    modifier = Modifier.padding(end = 7.dp)
                )
            }
        }
    }
}

@Composable
fun SliderControl(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("%.2f".format(value), color = Color.Gray)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

private fun autoEdit(bitmap: Bitmap): EditState {
    val w = minOf(bitmap.width, 80)
    val h = minOf(bitmap.height, 80)
    val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
    var sum = 0L
    var count = 0
    for (y in 0 until h) for (x in 0 until w) {
        val c = scaled.getPixel(x, y)
        sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
        count++
    }
    val avg = sum.toFloat() / max(1, count)
    scaled.recycle()
    val exposure = ((128f - avg) / 128f).coerceIn(-0.45f, 0.45f)
    val contrast = if (avg < 90 || avg > 185) 1.18f else 1.08f
    return EditState(exposure, contrast, 1.08f, 0.02f)
}

private fun renderBitmap(src: Bitmap, e: EditState): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(out)
    val cm = ColorMatrix()
    cm.setSaturation(e.saturation)
    val contrast = e.contrast
    val translate = (1f - contrast) * 128f + e.exposure * 80f
    val matrix = floatArrayOf(
        contrast, 0f, 0f, translate,
        0f, contrast, 0f, translate,
        0f, 0f, contrast, translate,
        0f, 0f, 0f, 1f, 0f
    )
    val contrastMatrix = ColorMatrix(matrix)
    val warmth = ColorMatrix(floatArrayOf(
        1f + e.warmth, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f - e.warmth, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))
    cm.postConcat(contrastMatrix)
    cm.postConcat(warmth)
    val paint = android.graphics.Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
    canvas.drawBitmap(src, 0f, 0f, paint)
    return out
}

private fun exportBitmap(activity: ComponentActivity, src: Bitmap, e: EditState) {
    val rendered = renderBitmap(src, e)
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PresetOne_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PresetOne")
    }
    val uri = activity.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    uri?.let {
        activity.contentResolver.openOutputStream(it)?.use { out ->
            rendered.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }
    }
    rendered.recycle()
}
