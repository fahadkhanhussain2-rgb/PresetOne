package com.presetone.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.presetone.app.engine.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Tab { PRESETS, ADJUST, COLOR, EFFECTS, TOOLS, AI }
private val channels = listOf("0" to "Red", "60" to "Yellow", "120" to "Green", "180" to "Cyan", "240" to "Blue", "300" to "Magenta")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PresetOneApp() } }
}

@Composable
fun PresetOneApp() {
    val context=LocalContext.current; val scope=rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }; var rendered by remember { mutableStateOf<Bitmap?>(null) }
    var state by remember { mutableStateOf(EditState()) }; var history by remember { mutableStateOf(listOf(EditState())) }; var index by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf(Tab.PRESETS) }; var category by remember { mutableStateOf("All") }; var compare by remember { mutableStateOf(false) }; var busy by remember { mutableStateOf(false) }; var job by remember { mutableStateOf<Job?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }; var panX by remember { mutableFloatStateOf(0f) }; var panY by remember { mutableFloatStateOf(0f) }

    fun render(s:EditState, push:Boolean=true){ if(push){ history=history.take(index+1)+s; index=history.lastIndex }; state=s; job?.cancel(); job=scope.launch { delay(55); busy=true; original?.let{ rendered=ImageProcessor.processImage(it,s) }; busy=false } }
    fun resetView(){zoom=1f;panX=0f;panY=0f}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){ uri:Uri? -> uri?.let{ scope.launch{busy=true; val b=ImageProcessor.decodeSampledBitmapFromUri(context,it); if(b!=null){original=b;rendered=b;state=EditState();history=listOf(state);index=0;resetView()}else Toast.makeText(context,"Could not open image",Toast.LENGTH_SHORT).show();busy=false} } }
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){ b:Bitmap? -> b?.let{original=it;rendered=it;state=EditState();history=listOf(state);index=0;resetView()} }

    MaterialTheme(colorScheme=darkColorScheme(background=Color(0xFF0B0D10),surface=Color(0xFF15181D),primary=Color(0xFF7C9CFF))){
        Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){
            if(original==null) HomeScreen({picker.launch("image/*")},{camera.launch(null)}) else {
                val image=if(compare) original else rendered
                Column(Modifier.fillMaxSize()){
                    TopBar(index,history.lastIndex,{original=null},{ if(index>0){index--;render(history[index],false)} },{ if(index<history.lastIndex){index++;render(history[index],false)} },{render(EditState())},{}, {exportBitmap(context,original!!,state);Toast.makeText(context,"Saved to Gallery",Toast.LENGTH_SHORT).show()})
                    Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black).pointerInput(Unit){detectTransformGestures{_,p,z,_ -> zoom=(zoom*z).coerceIn(1f,5f); if(zoom>1f){panX+=p.x;panY+=p.y}else resetView()}},contentAlignment=Alignment.Center){ image?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxSize().graphicsLayer(scaleX=zoom,scaleY=zoom,translationX=panX,translationY=panY),ContentScale.Fit)}; if(busy) CircularProgressIndicator() }
                    Row(Modifier.fillMaxWidth().background(Color(0xFF111419)).padding(horizontal=12.dp,vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){ Text(if(compare)"BEFORE" else "EDITED",fontSize=11.sp,color=Color.LightGray,fontWeight=FontWeight.Bold); Text("Hold Compare",fontSize=11.sp,color=Color.Gray); Button(onClick={compare=true},contentPadding=PaddingValues(horizontal=10.dp,vertical=4.dp)){Text("Compare",fontSize=11.sp)}; Button(onClick={compare=false},contentPadding=PaddingValues(horizontal=10.dp,vertical=4.dp)){Text("After",fontSize=11.sp)} }
                    EditorPanel(tab,category,{category=it},state,{render(it)},{ if(original!=null){render(ImageProcessor.autoEnhance(original!!))} },Modifier.height(310.dp))
                    BottomTabs(tab){tab=it}
                }
            }
        }
    }
}

@Composable private fun HomeScreen(onPick:()->Unit,onCamera:()->Unit){ Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){ Icon(Icons.Default.AutoAwesome,null,Modifier.size(64.dp),tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(18.dp)); Text("PresetOne",fontSize=36.sp,fontWeight=FontWeight.Bold); Text("Pro photo editing. One tap.",color=Color.Gray); Spacer(Modifier.height(40.dp)); Button(onClick=onPick,Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.AddPhotoAlternate,null);Spacer(Modifier.width(8.dp));Text("IMPORT PHOTO",fontWeight=FontWeight.Bold)}; Spacer(Modifier.height(12.dp)); OutlinedButton(onClick=onCamera,Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.CameraAlt,null);Spacer(Modifier.width(8.dp));Text("CAMERA",fontWeight=FontWeight.Bold)}; Spacer(Modifier.height(22.dp)); Text("RAW • PORTRAIT • CINEMATIC • SOCIAL",fontSize=11.sp,color=Color.DarkGray) } }

@Composable private fun TopBar(index:Int,last:Int,onClose:()->Unit,onUndo:()->Unit,onRedo:()->Unit,onReset:()->Unit,onSave:()->Unit){ Row(Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF15181D)).padding(horizontal=6.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onClose){Icon(Icons.Default.Close,null)};Text("PresetOne Studio",Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(enabled=index>0,onClick=onUndo){Icon(Icons.Default.Undo,null,tint=if(index>0)Color.White else Color.DarkGray)};IconButton(enabled=index<last,onClick=onRedo){Icon(Icons.Default.Redo,null,tint=if(index<last)Color.White else Color.DarkGray)};IconButton(onClick=onReset){Icon(Icons.Default.Refresh,null)};Button(onClick=onSave,contentPadding=PaddingValues(horizontal=12.dp,vertical=6.dp)){Text("EXPORT")}} }

@Composable private fun BottomTabs(tab:Tab,onTab:(Tab)->Unit){ Row(Modifier.fillMaxWidth().background(Color(0xFF15181D)).horizontalScroll(rememberScrollState()).padding(vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){Tab.values().forEach{t->val selected=tab==t;Column(Modifier.width(70.dp).clip(RoundedCornerShape(10.dp)).clickable{onTab(t)}.padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(when(t){Tab.PRESETS->Icons.Default.Style;Tab.ADJUST->Icons.Default.Tune;Tab.COLOR->Icons.Default.Palette;Tab.EFFECTS->Icons.Default.AutoAwesome;Tab.TOOLS->Icons.Default.Crop;Tab.AI->Icons.Default.Psychology},null,tint=if(selected)MaterialTheme.colorScheme.primary else Color.Gray);Text(t.name, fontSize=9.sp,color=if(selected)MaterialTheme.colorScheme.primary else Color.Gray,fontWeight=if(selected)FontWeight.Bold else FontWeight.Normal)}}} }

@Composable private fun EditorPanel(tab:Tab,category:String,onCategory:(String)->Unit,state:EditState,onEdit:(EditState)->Unit,onAuto:()->Unit,modifier:Modifier){ Box(modifier.background(Color(0xFF111419)).padding(12.dp)){when(tab){Tab.PRESETS->PresetsPanel(category,onCategory,onEdit);Tab.ADJUST->AdjustPanel(state,onEdit);Tab.COLOR->ColorPanel(state,onEdit);Tab.EFFECTS->EffectsPanel(state,onEdit);Tab.TOOLS->ToolsPanel();Tab.AI->AiPanel(onAuto)}} }

@Composable private fun PresetsPanel(category:String,onCategory:(String)->Unit,onEdit:(EditState)->Unit){val cats=listOf("All")+PresetCatalog.presets.map{it.category}.distinct();val list=if(category=="All")PresetCatalog.presets else PresetCatalog.presets.filter{it.category==category};Column{LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){items(cats){FilterChip(selected=category==it,onClick={onCategory(it)},label={Text(it,fontSize=11.sp)})}};Spacer(Modifier.height(12.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){items(list){p->Column(Modifier.width(82.dp).clickable{onEdit(p.editState)},horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF252A31)),contentAlignment=Alignment.Center){Text(p.name.take(2).uppercase(),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)};Text(p.name,fontSize=10.sp,maxLines=1,color=Color.LightGray)}}}}}}

@Composable private fun AdjustPanel(s:EditState,e:(EditState)->Unit){Column(Modifier.verticalScroll(rememberScrollState())){SliderRow("Exposure",s.exposure,-1f,1f){e(s.copy(exposure=it))};SliderRow("Contrast",s.contrast,0.5f,1.6f){e(s.copy(contrast=it))};SliderRow("Highlights",s.highlights,-1f,1f){e(s.copy(highlights=it))};SliderRow("Shadows",s.shadows,-1f,1f){e(s.copy(shadows=it))};SliderRow("Whites",s.whites,-1f,1f){e(s.copy(whites=it))};SliderRow("Blacks",s.blacks,-1f,1f){e(s.copy(blacks=it))};SliderRow("Temperature",s.temperature,-1f,1f){e(s.copy(temperature=it))};SliderRow("Tint",s.tint,-1f,1f){e(s.copy(tint=it))};SliderRow("Saturation",s.saturation,0f,1.8f){e(s.copy(saturation=it))};SliderRow("Vibrance",s.vibrance,-1f,1f){e(s.copy(vibrance=it))}}}

@Composable private fun ColorPanel(s:EditState,e:(EditState)->Unit){Column{Text("HSL Color Mixer",fontWeight=FontWeight.Bold);Text("Tune individual color ranges",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(8.dp));var channel by remember{mutableStateOf("0")};LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(channels){(key,name)->FilterChip(selected=channel==key,onClick={channel=key},label={Text(name,fontSize=10.sp)})}};Spacer(Modifier.height(8.dp));val a=s.hsl[channel]?:HslAdjustment();SliderRow("Hue",a.hue,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(hue=it))))};SliderRow("Saturation",a.saturation,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(saturation=it))))};SliderRow("Luminance",a.luminance,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(luminance=it))))}}
}

@Composable private fun EffectsPanel(s:EditState,e:(EditState)->Unit){Column(Modifier.verticalScroll(rememberScrollState())){SliderRow("Clarity",s.clarity,-1f,1f){e(s.copy(clarity=it))};SliderRow("Texture",s.texture,-1f,1f){e(s.copy(texture=it))};SliderRow("Dehaze",s.dehaze,-1f,1f){e(s.copy(dehaze=it))};SliderRow("Sharpen",s.sharpen,0f,1f){e(s.copy(sharpen=it))};SliderRow("Grain",s.grain,0f,1f){e(s.copy(grain=it))};SliderRow("Vignette",s.vignette,0f,1f){e(s.copy(vignette=it))};SliderRow("Fade",s.fade,0f,1f){e(s.copy(fade=it))}}}
@Composable private fun ToolsPanel(){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxSize(),verticalArrangement=Arrangement.Center){Icon(Icons.Default.Crop,null,Modifier.size(42.dp),tint=MaterialTheme.colorScheme.primary);Text("Crop / Rotate tools",fontWeight=FontWeight.Bold);Text("Advanced crop controls can be added without changing the editor engine.",fontSize=11.sp,color=Color.Gray)}}
@Composable private fun AiPanel(onAuto:()->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxSize(),verticalArrangement=Arrangement.Center){Icon(Icons.Default.Psychology,null,Modifier.size(42.dp),tint=MaterialTheme.colorScheme.primary);Text("AI Auto Enhance",fontWeight=FontWeight.Bold);Text("Balances exposure, contrast and tonal range locally on the phone.",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(12.dp));Button(onClick=onAuto){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(6.dp));Text("RUN AUTO ENHANCE")}}}

@Composable private fun SliderRow(label:String,value:Float,min:Float,max:Float,onValue:(Float)->Unit){Column{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontSize=12.sp);Text(String.format("%.2f",value),fontSize=11.sp,color=Color.Gray)};Slider(value=value.coerceIn(min,max),onValueChange=onValue,valueRange=min..max,modifier=Modifier.height(32.dp))}}

private fun exportBitmap(context:Context,source:Bitmap,state:EditState){val out=ImageProcessor.processImage(source,state);val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"PresetOne_${System.currentTimeMillis()}.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PresetOne")};val uri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:return;context.contentResolver.openOutputStream(uri)?.use{out.compress(Bitmap.CompressFormat.JPEG,96,it)}}
