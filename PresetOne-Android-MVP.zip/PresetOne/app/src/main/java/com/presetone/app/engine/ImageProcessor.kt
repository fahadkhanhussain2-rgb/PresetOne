package com.presetone.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import kotlin.math.*

 data class HslAdjustment(val hue: Float = 0f, val saturation: Float = 0f, val luminance: Float = 0f)

data class EditState(
    val exposure: Float = 0f,
    val contrast: Float = 1f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val whites: Float = 0f,
    val blacks: Float = 0f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val saturation: Float = 1f,
    val vibrance: Float = 0f,
    val fade: Float = 0f,
    val clarity: Float = 0f,
    val texture: Float = 0f,
    val dehaze: Float = 0f,
    val sharpen: Float = 0f,
    val grain: Float = 0f,
    val vignette: Float = 0f,
    val hsl: Map<String, HslAdjustment> = emptyMap()
)

data class Preset(val name: String, val category: String, val editState: EditState)

object PresetCatalog {
    private fun e(exposure: Float=0f, contrast: Float=1f, saturation: Float=1f, temperature: Float=0f, fade: Float=0f, vignette: Float=0f, grain: Float=0f, vibrance: Float=0f) = EditState(exposure=exposure, contrast=contrast, saturation=saturation, temperature=temperature, fade=fade, vignette=vignette, grain=grain, vibrance=vibrance)
    val presets = listOf(
        Preset("Original","Basic", EditState()), Preset("Clean","Basic", e(0.05f,1.06f,1.02f,0.01f)),
        Preset("Cinematic","Cinematic", e(-0.03f,1.18f,1.06f,-0.02f,0.03f,0.18f)),
        Preset("Teal Mood","Cinematic", e(-0.08f,1.24f,0.92f,-0.04f,0.02f,0.28f)),
        Preset("Golden Film","Cinematic", e(0.05f,1.12f,1.10f,0.12f,0.04f,0.12f,0.08f)),
        Preset("Noir","Film", e(-0.04f,1.28f,0f,0f,0.02f,0.3f,0.03f)),
        Preset("Vintage","Film", e(-0.04f,1.08f,0.84f,0.08f,0.10f,0.15f,0.12f)),
        Preset("Faded 90s","Film", e(0.02f,0.96f,0.82f,0.05f,0.16f,0.08f,0.10f)),
        Preset("Analog","Film", e(-0.02f,1.10f,0.94f,0.06f,0.06f,0.16f,0.14f)),
        Preset("Portrait","Portrait", e(0.04f,1.05f,1.02f,0.03f,0f,0.08f)),
        Preset("Soft Skin","Portrait", e(0.08f,0.96f,0.98f,0.04f,0.02f,0.05f)),
        Preset("Rich Skin","Portrait", e(0.02f,1.10f,1.08f,0.07f,0f,0.06f)),
        Preset("Travel Pop","Travel", e(0.04f,1.16f,1.18f,0.02f,0f,0.08f,0f,0.10f)),
        Preset("Nature","Travel", e(0.02f,1.12f,1.12f,-0.01f,0f,0.04f,0f,0.08f)),
        Preset("Ocean","Travel", e(0f,1.16f,1.08f,-0.08f,0f,0.10f)),
        Preset("Sunset","Travel", e(0.08f,1.12f,1.14f,0.16f,0f,0.08f)),
        Preset("Night Blue","Night", e(0.06f,1.22f,0.96f,-0.13f,0.02f,0.26f)),
        Preset("Neon","Night", e(0.02f,1.28f,1.16f,-0.10f,0f,0.30f,0.02f,0.08f)),
        Preset("Low Light","Night", e(0.12f,1.10f,1.02f,-0.03f,0f,0.18f)),
        Preset("Social Bright","Social", e(0.10f,1.04f,1.12f,0.03f,0f,0.04f,0f,0.08f)),
        Preset("Instagram","Social", e(0.06f,1.10f,1.10f,0.02f,0.02f,0.06f)),
        Preset("Moody","Social", e(-0.10f,1.28f,0.88f,-0.02f,0.02f,0.24f)),
        Preset("B&W","Creative", e(0f,1.18f,0f,0f,0.01f,0.20f,0.02f)),
        Preset("High Contrast","Creative", e(0f,1.38f,1.04f,0f,0f,0.16f)),
        Preset("Matte","Creative", e(0.03f,0.96f,0.92f,0.03f,0.18f,0.06f)),
        Preset("Bright Air","Creative", e(0.16f,0.94f,1.02f,0.02f,0.04f)),
        Preset("Film Grain","Film", e(-0.02f,1.10f,0.98f,0.02f,0.04f,0.10f,0.24f)),
        Preset("Warm","Basic", e(0.04f,1.04f,1.04f,0.14f)),
        Preset("Cool","Basic", e(0f,1.06f,1.02f,-0.12f)),
        Preset("Drama","Cinematic", e(-0.08f,1.34f,0.94f,-0.02f,0.01f,0.32f))
    )
}

object ImageProcessor {
    fun decodeSampledBitmapFromUri(context: Context, uri: Uri, reqWidth: Int = 2048, reqHeight: Int = 2048): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        val opts = BitmapFactory.Options().apply { inSampleSize = calculateInSampleSize(bounds, reqWidth, reqHeight); inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
    private fun calculateInSampleSize(o: BitmapFactory.Options, rw: Int, rh: Int): Int {
        var s = 1
        while (o.outHeight / s > rh || o.outWidth / s > rw) s *= 2
        return s
    }

    fun autoEnhance(src: Bitmap): EditState {
        var sum = 0.0; var sum2 = 0.0; var n = 0
        val step = max(1, max(src.width, src.height) / 80)
        for (y in 0 until src.height step step) for (x in 0 until src.width step step) {
            val c = src.getPixel(x,y); val l = (0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))/255.0
            sum += l; sum2 += l*l; n++
        }
        if (n == 0) return EditState()
        val mean=sum/n; val sd=sqrt(max(0.0,sum2/n-mean*mean))
        return EditState(exposure=((0.50-mean)*1.35).toFloat().coerceIn(-0.45f,0.45f), contrast=(1.0+((0.24-sd)*0.9)).toFloat().coerceIn(0.85f,1.25f), shadows=((0.48-mean)*0.6).toFloat().coerceIn(-0.25f,0.30f), highlights=((mean-0.55)*-0.35).toFloat().coerceIn(-0.25f,0.20f), vibrance=0.06f)
    }

    fun processImage(src: Bitmap, s: EditState): Bitmap {
        val w=src.width; val h=src.height; val input=IntArray(w*h); src.getPixels(input,0,w,0,0,w,h); val out=IntArray(w*h)
        val maxV=255f
        for(i in input.indices){
            var r=Color.red(input[i]).toFloat(); var g=Color.green(input[i]).toFloat(); var b=Color.blue(input[i]).toFloat()
            val lum=(0.2126f*r+0.7152f*g+0.0722f*b)/255f
            val exposure=2f.pow(s.exposure)
            r*=exposure; g*=exposure; b*=exposure
            fun tone(v:Float):Float { var x=v/255f; x=(x-0.5f)*s.contrast+0.5f; val sh=max(0f,0.5f-x)*s.shadows*1.8f; val hi=max(0f,x-0.5f)*s.highlights*-1.5f; x += sh+hi; x += s.whites*max(0f,(x-0.55f)*1.4f); x += s.blacks*max(0f,(0.45f-x)*1.4f); return x*255f }
            r=tone(r); g=tone(g); b=tone(b)
            val temp=s.temperature*28f; r+=temp; b-=temp
            val ti=s.tint*18f; r+=ti; g-=ti; b+=ti
            val gray=(r+g+b)/3f; val mx=max(r,max(g,b)); val vibr=(1f+(s.vibrance*(1f-(mx-min(r,min(g,b)))/max(1f,mx))))
            r=gray+(r-gray)*s.saturation*vibr; g=gray+(g-gray)*s.saturation*vibr; b=gray+(b-gray)*s.saturation*vibr
            val fade=s.fade*18f; r+=fade; g+=fade; b+=fade
            if(s.clarity!=0f){ val c=(s.clarity*0.55f); r=(r-128f)*(1f+c)+128f; g=(g-128f)*(1f+c)+128f; b=(b-128f)*(1f+c)+128f }
            if(s.dehaze!=0f){ val d=s.dehaze*0.28f; r=(r-128f)*(1+d)+128f; g=(g-128f)*(1+d)+128f; b=(b-128f)*(1+d)+128f }
            if(s.hsl.isNotEmpty()){
                val hsv=FloatArray(3); Color.RGBToHSV(r.coerceIn(0f,255f).toInt(),g.coerceIn(0f,255f).toInt(),b.coerceIn(0f,255f).toInt(),hsv)
                val keys=s.hsl.keys; for(k in keys){ val center=k.toFloatOrNull() ?: continue; var d=abs(hsv[0]-center); if(d>180f)d=360f-d; val weight=(1f-d/48f).coerceIn(0f,1f); val a=s.hsl[k] ?: continue; hsv[0]=(hsv[0]+a.hue*weight*18f+360f)%360f; hsv[1]=(hsv[1]+a.saturation*weight).coerceIn(0f,1f); val v=(hsv[2]+a.luminance*weight).coerceIn(0f,1f); val rgb=FloatArray(3); Color.colorToHSV(Color.HSVToColor(floatArrayOf(hsv[0],hsv[1],v)),hsv); r=Color.red(Color.HSVToColor(hsv)).toFloat(); g=Color.green(Color.HSVToColor(hsv)).toFloat(); b=Color.blue(Color.HSVToColor(hsv)).toFloat(); break }
            }
            out[i]=Color.argb(255,r.roundToInt().coerceIn(0,255),g.roundToInt().coerceIn(0,255),b.roundToInt().coerceIn(0,255))
        }
        var bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); bmp.setPixels(out,0,w,0,0,w,h)
        if(s.vignette!=0f) bmp=applyVignette(bmp,s.vignette)
        if(s.sharpen>0.01f) bmp=applySharpen(bmp,s.sharpen)
        if(s.grain>0.01f) bmp=applyGrain(bmp,s.grain)
        return bmp
    }
    private fun applyVignette(src:Bitmap, amount:Float):Bitmap { val out=src.copy(Bitmap.Config.ARGB_8888,true); val p=out.pixelsCopy(); val cx=src.width/2f; val cy=src.height/2f; val maxD=sqrt(cx*cx+cy*cy); for(y in 0 until src.height)for(x in 0 until src.width){ val d=sqrt((x-cx).pow(2)+(y-cy).pow(2))/maxD; val f=1f-(amount.coerceIn(0f,1f)*d*d*0.72f); val c=p[y*src.width+x]; p[y*src.width+x]=Color.argb(255,(Color.red(c)*f).roundToInt(),(Color.green(c)*f).roundToInt(),(Color.blue(c)*f).roundToInt()) }; out.setPixels(p,0,src.width,0,0,src.width,src.height); return out }
    private fun applySharpen(src:Bitmap, amount:Float):Bitmap { val w=src.width; val h=src.height; val a=IntArray(w*h); src.getPixels(a,0,w,0,0,w,h); val o=a.copyOf(); val k=amount.coerceIn(0f,1f)*0.55f; for(y in 1 until h-1)for(x in 1 until w-1){ val i=y*w+x; fun ch(c:Int)=Color.red(c); val center=a[i]; val avg=(ch(a[i-1])+ch(a[i+1])+ch(a[i-w])+ch(a[i+w]))/4f; val rr=(Color.red(center)+(Color.red(center)-avg)*k).roundToInt().coerceIn(0,255); val gg=(Color.green(center)+(Color.green(center)-((Color.green(a[i-1])+Color.green(a[i+1])+Color.green(a[i-w])+Color.green(a[i+w]))/4f))*k).roundToInt().coerceIn(0,255); val bb=(Color.blue(center)+(Color.blue(center)-((Color.blue(a[i-1])+Color.blue(a[i+1])+Color.blue(a[i-w])+Color.blue(a[i+w]))/4f))*k).roundToInt().coerceIn(0,255); o[i]=Color.rgb(rr,gg,bb) }; val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(o,0,w,0,0,w,h); return out }
    private fun applyGrain(src:Bitmap, amount:Float):Bitmap { val w=src.width; val h=src.height; val a=IntArray(w*h); src.getPixels(a,0,w,0,0,w,h); val rnd=java.util.Random(17); val amp=amount.coerceIn(0f,1f)*24f; for(i in a.indices){ val n=(rnd.nextGaussian()*amp).roundToInt(); val c=a[i]; a[i]=Color.rgb((Color.red(c)+n).coerceIn(0,255),(Color.green(c)+n).coerceIn(0,255),(Color.blue(c)+n).coerceIn(0,255)) }; val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(a,0,w,0,0,w,h); return out }
    private fun Bitmap.pixelsCopy():IntArray { val a=IntArray(width*height); getPixels(a,0,width,0,0,width,height); return a }
}
