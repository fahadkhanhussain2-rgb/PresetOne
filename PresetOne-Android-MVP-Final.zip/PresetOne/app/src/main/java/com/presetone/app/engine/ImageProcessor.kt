package com.presetone.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import kotlin.math.*

data class HslAdjustment(val hue: Float = 0f, val saturation: Float = 0f, val luminance: Float = 0f)

data class EditState(
    val exposure: Float = 0f, val contrast: Float = 1f,
    val highlights: Float = 0f, val shadows: Float = 0f,
    val whites: Float = 0f, val blacks: Float = 0f,
    val temperature: Float = 0f, val tint: Float = 0f,
    val saturation: Float = 1f, val vibrance: Float = 0f,
    val fade: Float = 0f, val clarity: Float = 0f,
    val texture: Float = 0f, val dehaze: Float = 0f,
    val sharpen: Float = 0f, val grain: Float = 0f,
    val vignette: Float = 0f,
    val hsl: Map<String, HslAdjustment> = emptyMap()
)

data class Preset(val name: String, val category: String, val state: EditState)

object PresetCatalog {
    private fun p(name: String, category: String, e: Float=0f, c: Float=1f, sat: Float=1f, temp: Float=0f, fade: Float=0f, vig: Float=0f, grain: Float=0f, vib: Float=0f) = Preset(name, category, EditState(e,c,temperature=temp,saturation=sat,fade=fade,vignette=vig,grain=grain,vibrance=vib))
    val presets = listOf(
        p("Original","Basic"), p("Clean","Basic",.05f,1.06f,1.02f), p("Warm","Basic",.04f,1.04f,1.04f,.14f), p("Cool","Basic",0f,1.06f,1.02f,-.12f),
        p("Cinematic","Cinematic",-.03f,1.18f,1.06f,-.02f,.03f,.18f), p("Teal Mood","Cinematic",-.08f,1.24f,.92f,-.04f,.02f,.28f), p("Drama","Cinematic",-.08f,1.34f,.94f,-.02f,.01f,.32f),
        p("Golden Film","Film",.05f,1.12f,1.10f,.12f,.04f,.12f,.08f), p("Vintage","Film",-.04f,1.08f,.84f,.08f,.10f,.15f,.12f), p("Analog","Film",-.02f,1.10f,.94f,.06f,.06f,.16f,.14f), p("Noir","Film",-.04f,1.28f,0f,0f,.02f,.30f,.03f),
        p("Portrait","Portrait",.04f,1.05f,1.02f,.03f,0f,.08f), p("Soft Skin","Portrait",.08f,.96f,.98f,.04f,.02f,.05f), p("Rich Skin","Portrait",.02f,1.10f,1.08f,.07f,0f,.06f),
        p("Travel Pop","Travel",.04f,1.16f,1.18f,.02f,0f,.08f,0f,.10f), p("Nature","Travel",.02f,1.12f,1.12f,-.01f,0f,.04f,0f,.08f), p("Ocean","Travel",0f,1.16f,1.08f,-.08f,0f,.10f), p("Sunset","Travel",.08f,1.12f,1.14f,.16f,0f,.08f),
        p("Night Blue","Night",.06f,1.22f,.96f,-.13f,.02f,.26f), p("Neon","Night",.02f,1.28f,1.16f,-.10f,0f,.30f,.02f,.08f), p("Low Light","Night",.12f,1.10f,1.02f,-.03f,0f,.18f),
        p("Social Bright","Social",.10f,1.04f,1.12f,.03f), p("Social Pop","Social",.06f,1.10f,1.10f,.02f,.02f,.06f), p("Moody","Social",-.10f,1.28f,.88f,-.02f,.02f,.24f),
        p("High Contrast","Creative",0f,1.38f,1.04f,0f,0f,.16f), p("Matte","Creative",.03f,.96f,.92f,.03f,.18f,.06f), p("Bright Air","Creative",.16f,.94f,1.02f,.02f,.04f), p("Film Grain","Creative",-.02f,1.10f,.98f,.02f,.04f,.10f,.24f)
    )
}

object ImageProcessor {
    fun decodeSampledBitmapFromUri(context: Context, uri: Uri, reqWidth: Int = 2048, reqHeight: Int = 2048): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, reqWidth, reqHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun sampleSize(w: Int, h: Int, rw: Int, rh: Int): Int {
        var s = 1
        while (w / s > rw || h / s > rh) s *= 2
        return s
    }

    fun autoEnhance(src: Bitmap): EditState {
        var sum = 0.0; var sum2 = 0.0; var n = 0
        val step = max(1, max(src.width, src.height) / 80)
        for (y in 0 until src.height step step) for (x in 0 until src.width step step) {
            val c = src.getPixel(x, y)
            val l = (0.2126 * Color.red(c) + 0.7152 * Color.green(c) + 0.0722 * Color.blue(c)) / 255.0
            sum += l; sum2 += l * l; n++
        }
        if (n == 0) return EditState()
        val mean = sum / n
        val sd = sqrt(max(0.0, sum2 / n - mean * mean))
        return EditState(
            exposure = ((.50 - mean) * 1.35).toFloat().coerceIn(-.45f, .45f),
            contrast = (1.0 + (.24 - sd) * .9).toFloat().coerceIn(.85f, 1.25f),
            shadows = ((.48 - mean) * .6).toFloat().coerceIn(-.25f, .30f),
            highlights = ((mean - .55) * -.35).toFloat().coerceIn(-.25f, .20f),
            vibrance = .06f
        )
    }

    fun processImage(src: Bitmap, s: EditState): Bitmap {
        val w = src.width; val h = src.height
        val input = IntArray(w * h); src.getPixels(input, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        val exposure = 2f.pow(s.exposure)
        for (i in input.indices) {
            var r = Color.red(input[i]).toFloat() * exposure
            var g = Color.green(input[i]).toFloat() * exposure
            var b = Color.blue(input[i]).toFloat() * exposure
            fun tone(v: Float): Float {
                var x = v / 255f
                x = (x - .5f) * s.contrast + .5f
                x += max(0f, .5f - x) * s.shadows * 1.8f
                x -= max(0f, x - .5f) * s.highlights * 1.5f
                x += s.whites * max(0f, x - .55f) * 1.4f
                x += s.blacks * max(0f, .45f - x) * 1.4f
                return x * 255f
            }
            r = tone(r); g = tone(g); b = tone(b)
            val t = s.temperature * 28f; r += t; b -= t
            val ti = s.tint * 18f; r += ti; g -= ti; b += ti
            val gray = (r + g + b) / 3f
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            val vib = 1f + s.vibrance * (1f - (mx - mn) / max(1f, mx))
            r = gray + (r - gray) * s.saturation * vib
            g = gray + (g - gray) * s.saturation * vib
            b = gray + (b - gray) * s.saturation * vib
            val fade = s.fade * 18f; r += fade; g += fade; b += fade
            if (s.clarity != 0f || s.dehaze != 0f || s.texture != 0f) {
                val amount = s.clarity * .55f + s.dehaze * .28f + s.texture * .20f
                r = (r - 128f) * (1f + amount) + 128f
                g = (g - 128f) * (1f + amount) + 128f
                b = (b - 128f) * (1f + amount) + 128f
            }
            if (s.hsl.isNotEmpty()) {
                val hsv = FloatArray(3)
                Color.RGBToHSV(r.roundToInt().coerceIn(0,255), g.roundToInt().coerceIn(0,255), b.roundToInt().coerceIn(0,255), hsv)
                var dh = 0f; var ds = 0f; var dl = 0f
                for ((key, a) in s.hsl) {
                    val center = key.toFloatOrNull() ?: continue
                    var d = abs(hsv[0] - center); if (d > 180f) d = 360f - d
                    val weight = (1f - d / 48f).coerceIn(0f, 1f)
                    dh += a.hue * weight * 18f; ds += a.saturation * weight; dl += a.luminance * weight
                }
                hsv[0] = (hsv[0] + dh + 360f) % 360f
                hsv[1] = (hsv[1] + ds).coerceIn(0f, 1f)
                hsv[2] = (hsv[2] + dl).coerceIn(0f, 1f)
                val c = Color.HSVToColor(hsv); r = Color.red(c).toFloat(); g = Color.green(c).toFloat(); b = Color.blue(c).toFloat()
            }
            out[i] = Color.rgb(r.roundToInt().coerceIn(0,255), g.roundToInt().coerceIn(0,255), b.roundToInt().coerceIn(0,255))
        }
        var result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, w, 0, 0, w, h)
        if (s.vignette > 0f) result = vignette(result, s.vignette)
        if (s.sharpen > 0f) result = sharpen(result, s.sharpen)
        if (s.grain > 0f) result = grain(result, s.grain)
        return result
    }

    private fun vignette(src: Bitmap, amount: Float): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true); val p = IntArray(src.width * src.height); src.getPixels(p,0,src.width,0,0,src.width,src.height)
        val cx = src.width / 2f; val cy = src.height / 2f; val maxD = sqrt(cx*cx + cy*cy)
        for (y in 0 until src.height) for (x in 0 until src.width) { val d = sqrt((x-cx).pow(2)+(y-cy).pow(2))/maxD; val f = 1f - amount.coerceIn(0f,1f)*d*d*.72f; val c=p[y*src.width+x]; p[y*src.width+x]=Color.rgb((Color.red(c)*f).roundToInt().coerceIn(0,255),(Color.green(c)*f).roundToInt().coerceIn(0,255),(Color.blue(c)*f).roundToInt().coerceIn(0,255)) }
        out.setPixels(p,0,src.width,0,0,src.width,src.height); return out
    }

    private fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w=src.width; val h=src.height; val a=IntArray(w*h); src.getPixels(a,0,w,0,0,w,h); val o=a.copyOf(); val k=amount.coerceIn(0f,1f)*.55f
        for (y in 1 until h-1) for (x in 1 until w-1) { val i=y*w+x; val c=a[i]; val l=a[i-1]; val r=a[i+1]; val u=a[i-w]; val d=a[i+w];
            val rr=(Color.red(c)+(Color.red(c)-(Color.red(l)+Color.red(r)+Color.red(u)+Color.red(d))/4f)*k).roundToInt().coerceIn(0,255)
            val gg=(Color.green(c)+(Color.green(c)-(Color.green(l)+Color.green(r)+Color.green(u)+Color.green(d))/4f)*k).roundToInt().coerceIn(0,255)
            val bb=(Color.blue(c)+(Color.blue(c)-(Color.blue(l)+Color.blue(r)+Color.blue(u)+Color.blue(d))/4f)*k).roundToInt().coerceIn(0,255)
            o[i]=Color.rgb(rr,gg,bb)
        }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also { it.setPixels(o,0,w,0,0,w,h) }
    }

    private fun grain(src: Bitmap, amount: Float): Bitmap {
        val w=src.width; val h=src.height; val a=IntArray(w*h); src.getPixels(a,0,w,0,0,w,h); val random=java.util.Random(17); val amp=amount.coerceIn(0f,1f)*24f
        for(i in a.indices){ val n=(random.nextGaussian()*amp).roundToInt(); val c=a[i]; a[i]=Color.rgb((Color.red(c)+n).coerceIn(0,255),(Color.green(c)+n).coerceIn(0,255),(Color.blue(c)+n).coerceIn(0,255)) }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also { it.setPixels(a,0,w,0,0,w,h) }
    }
}
