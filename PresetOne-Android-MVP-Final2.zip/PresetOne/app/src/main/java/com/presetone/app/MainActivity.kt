package com.presetone.app

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity as ActivityBase
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.presetone.app.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Tab { PRESETS, ADJUST, COLOR, EFFECTS, TOOLS, AI }
private val channels = listOf("0" to "Red", "60" to "Yellow", "120" to "Green", "180" to "Cyan", "240" to "Blue", "300" to "Magenta")

class MainActivity : ActivityBase() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PresetOneApp() } }
}

@Composable
private fun PresetOneApp( ) {
    val appContext = LocalContext.current; val scope = rememberCoroutineScope()
    var original by remember { mutableStateOf<Bitmap?>(null) }; var rendered by remember { mutableStateOf<Bitmap?>(null) }
    var state by remember { mutableStateOf(EditState()) }; var history by remember { mutableStateOf(listOf(EditState())) }; var index by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf(Tab.PRESETS) }; var category by remember { mutableStateOf("All") }; var before by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }; var job by remember { mutableStateOf<Job?>(null) }; var zoom by remember { mutableFloatStateOf(1f) }; var panX by remember { mutableFloatStateOf(0f) }; var panY by remember { mutableFloatStateOf(0f) }

    fun resetView(){ zoom=1f; panX=0f; panY=0f }
    fun render(next: EditState, push: Boolean = true) {
        if (push) { history = history.take(index+1) + next; index = history.lastIndex }; state = next; job?.cancel()
        job = scope.launch { delay(45); busy=true; val src=original; if(src!=null) rendered=withContext(Dispatchers.Default){ ImageProcessor.processImage(src,next) }; busy=false }
    }
    fun openBitmap(b: Bitmap){ original=b; rendered=b; state=EditState(); history=listOf(state); index=0; before=false; resetView() }

    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){ uri: Uri? -> uri?.let{ scope.launch{ busy=true; val b=withContext(Dispatchers.IO){ImageProcessor.decodeSampledBitmapFromUri(appContext,it)}; if(b!=null)openBitmap(b) else Toast.makeText(appContext,"Could not open image",Toast.LENGTH_SHORT).show(); busy=false } } }
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){ b:Bitmap? -> if(b!=null)openBitmap(b) }

    MaterialTheme(colorScheme=darkColorScheme(background=ComposeColor(0xFF0A0C0F),surface=ComposeColor(0xFF14171C),primary=ComposeColor(0xFF8EA7FF))){
        Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){
            if(original==null) HomeScreen({picker.launch("image/*")},{camera.launch(null)}) else {
                val image=if(before) original else rendered
                Column(Modifier.fillMaxSize()){
                    TopBar(index,history.lastIndex,{original=null},{if(index>0){index--;render(history[index],false)}},{if(index<history.lastIndex){index++;render(history[index],false)}},{render(EditState())},{scope.launch{busy=true; val src=original!!; val s=state; withContext(Dispatchers.Default){exportBitmap(appContext,src,s)}; busy=false; Toast.makeText(appContext,"Saved to Gallery",Toast.LENGTH_SHORT).show()}})
                    Box(Modifier.fillMaxWidth().weight(1f).background(ComposeColor.Black).pointerInput(Unit){detectTransformGestures{_,pan,scale,_->zoom=(zoom*scale).coerceIn(1f,5f); if(zoom>1f){panX+=pan.x;panY+=pan.y}else resetView()}},contentAlignment=Alignment.Center){ image?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxSize().graphicsLayer(scaleX=zoom,scaleY=zoom,translationX=panX,translationY=panY),contentScale=ContentScale.Fit)}; if(busy)CircularProgressIndicator() }
                    Row(Modifier.fillMaxWidth().background(ComposeColor(0xFF111419)).padding(8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){ Text(if(before)"BEFORE" else "EDITED",fontSize=11.sp,fontWeight=FontWeight.Bold,color=ComposeColor.LightGray); Row{Button(onClick={before=true}){Text("Before")}; Spacer(Modifier.width(6.dp));Button(onClick={before=false}){Text("After")}} }
                    EditorPanel(tab,category,{category=it},state,{render(it)},{original?.let{render(ImageProcessor.autoEnhance(it))}},Modifier.height(300.dp)); BottomTabs(tab){tab=it}
                }
            }
        }
    }
}

@Composable private fun HomeScreen(onPick:()->Unit,onCamera:()->Unit){ Column(Modifier.fillMaxSize().padding(22.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){ Icon(Icons.Default.AutoAwesome,null,Modifier.size(68.dp),tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(16.dp)); Text("PresetOne",fontSize=36.sp,fontWeight=FontWeight.Bold); Text("Professional photo editing",color=ComposeColor.Gray); Spacer(Modifier.height(36.dp)); Button(onClick=onPick,Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.AddPhotoAlternate,null);Spacer(Modifier.width(8.dp));Text("IMPORT PHOTO",fontWeight=FontWeight.Bold)}; Spacer(Modifier.height(12.dp));OutlinedButton(onClick=onCamera,Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.CameraAlt,null);Spacer(Modifier.width(8.dp));Text("CAMERA",fontWeight=FontWeight.Bold)} } }

@Composable private fun TopBar(index:Int,last:Int,onClose:()->Unit,onUndo:()->Unit,onRedo:()->Unit,onReset:()->Unit,onSave:()->Unit){ Row(Modifier.fillMaxWidth().height(58.dp).background(ComposeColor(0xFF15181D)),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onClose){Icon(Icons.Default.Close,null)};Text("PresetOne Studio",Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(enabled=index>0,onClick=onUndo){Icon(Icons.Default.Undo,null)};IconButton(enabled=index<last,onClick=onRedo){Icon(Icons.Default.Redo,null)};IconButton(onClick=onReset){Icon(Icons.Default.Refresh,null)};Button(onClick=onSave){Text("EXPORT")}} }

@Composable private fun BottomTabs(tab:Tab,onTab:(Tab)->Unit){ Row(Modifier.fillMaxWidth().background(ComposeColor(0xFF15181D)).horizontalScroll(rememberScrollState()).padding(vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){Tab.values().forEach{t->val selected=tab==t;val icon=when(t){Tab.PRESETS->Icons.Default.AutoAwesome;Tab.ADJUST->Icons.Default.Tune;Tab.COLOR->Icons.Default.Palette;Tab.EFFECTS->Icons.Default.AutoFixHigh;Tab.TOOLS->Icons.Default.Crop;Tab.AI->Icons.Default.AutoAwesome};Column(Modifier.width(72.dp).clip(RoundedCornerShape(10.dp)).clickable{onTab(t)}.padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=if(selected)MaterialTheme.colorScheme.primary else ComposeColor.Gray);Text(t.name,fontSize=9.sp,color=if(selected)MaterialTheme.colorScheme.primary else ComposeColor.Gray)}}} }

@Composable private fun EditorPanel(tab:Tab,category:String,onCategory:(String)->Unit,s:EditState,e:(EditState)->Unit,onAuto:()->Unit,modifier:Modifier){ Box(modifier.background(ComposeColor(0xFF111419)).padding(12.dp)){when(tab){Tab.PRESETS->PresetsPanel(category,onCategory,e);Tab.ADJUST->AdjustPanel(s,e);Tab.COLOR->ColorPanel(s,e);Tab.EFFECTS->EffectsPanel(s,e);Tab.TOOLS->ToolsPanel();Tab.AI->AiPanel(onAuto)}} }
@Composable private fun PresetsPanel(category:String,onCategory:(String)->Unit,e:(EditState)->Unit){val cats=listOf("All")+PresetCatalog.presets.map{it.category}.distinct();val list=if(category=="All")PresetCatalog.presets else PresetCatalog.presets.filter{it.category==category};Column{LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(cats){FilterChip(selected=category==it,onClick={onCategory(it)},label={Text(it,fontSize=10.sp)})}};Spacer(Modifier.height(10.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){items(list){p->Column(Modifier.width(84.dp).clickable{e(p.state)},horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(ComposeColor(0xFF252A31)),contentAlignment=Alignment.Center){Text(p.name.take(2).uppercase(),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)};Text(p.name,fontSize=10.sp,maxLines=1,color=ComposeColor.LightGray)}}}}}
@Composable private fun AdjustPanel(s:EditState,e:(EditState)->Unit){Column(Modifier.verticalScroll(rememberScrollState())){SliderRow("Exposure",s.exposure,-1f,1f){e(s.copy(exposure=it))};SliderRow("Contrast",s.contrast,.5f,1.6f){e(s.copy(contrast=it))};SliderRow("Highlights",s.highlights,-1f,1f){e(s.copy(highlights=it))};SliderRow("Shadows",s.shadows,-1f,1f){e(s.copy(shadows=it))};SliderRow("Whites",s.whites,-1f,1f){e(s.copy(whites=it))};SliderRow("Blacks",s.blacks,-1f,1f){e(s.copy(blacks=it))};SliderRow("Temperature",s.temperature,-1f,1f){e(s.copy(temperature=it))};SliderRow("Tint",s.tint,-1f,1f){e(s.copy(tint=it))};SliderRow("Saturation",s.saturation,0f,1.8f){e(s.copy(saturation=it))};SliderRow("Vibrance",s.vibrance,-1f,1f){e(s.copy(vibrance=it))}}}
@Composable private fun ColorPanel(s:EditState,e:(EditState)->Unit){var channel by remember{mutableStateOf("0")};Column{Text("HSL Color Mixer",fontWeight=FontWeight.Bold);Text("Hue • Saturation • Luminance",fontSize=11.sp,color=ComposeColor.Gray);Spacer(Modifier.height(8.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(5.dp)){items(channels){(key,name)->FilterChip(selected=channel==key,onClick={channel=key},label={Text(name,fontSize=9.sp)})}};val a=s.hsl[channel]?:HslAdjustment();SliderRow("Hue",a.hue,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(hue=it))))};SliderRow("Saturation",a.saturation,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(saturation=it))))};SliderRow("Luminance",a.luminance,-1f,1f){e(s.copy(hsl=s.hsl+(channel to a.copy(luminance=it))))}}}
@Composable private fun EffectsPanel(s:EditState,e:(EditState)->Unit){Column(Modifier.verticalScroll(rememberScrollState())){SliderRow("Clarity",s.clarity,-1f,1f){e(s.copy(clarity=it))};SliderRow("Texture",s.texture,-1f,1f){e(s.copy(texture=it))};SliderRow("Dehaze",s.dehaze,-1f,1f){e(s.copy(dehaze=it))};SliderRow("Sharpen",s.sharpen,0f,1f){e(s.copy(sharpen=it))};SliderRow("Grain",s.grain,0f,1f){e(s.copy(grain=it))};SliderRow("Vignette",s.vignette,0f,1f){e(s.copy(vignette=it))};SliderRow("Fade",s.fade,0f,1f){e(s.copy(fade=it))}}}
@Composable private fun ToolsPanel(){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.Crop,null,Modifier.size(40.dp),tint=MaterialTheme.colorScheme.primary);Text("Crop & transform",fontWeight=FontWeight.Bold);Text("Zoom and pan are available above.",fontSize=11.sp,color=ComposeColor.Gray)}}
@Composable private fun AiPanel(onAuto:()->Unit){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.AutoAwesome,null,Modifier.size(40.dp),tint=MaterialTheme.colorScheme.primary);Text("AI Auto Enhance",fontWeight=FontWeight.Bold);Text("Automatic exposure, contrast and tonal balance",fontSize=11.sp,color=ComposeColor.Gray);Spacer(Modifier.height(10.dp));Button(onClick=onAuto){Text("RUN AUTO ENHANCE")}}}
@Composable private fun SliderRow(label:String,value:Float,min:Float,max:Float,onValue:(Float)->Unit){Column{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontSize=12.sp);Text("%.2f".format(value),fontSize=10.sp,color=ComposeColor.Gray)};Slider(value=value.coerceIn(min,max),onValueChange=onValue,valueRange=min..max,modifier=Modifier.height(32.dp))}}

private fun exportBitmap(context:android.content.Context,source:Bitmap,state:EditState){val out=ImageProcessor.processImage(source,state);val values=android.content.ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"PresetOne_${System.currentTimeMillis()}.jpg");put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PresetOne")};val uri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:return;context.contentResolver.openOutputStream(uri)?.use{out.compress(Bitmap.CompressFormat.JPEG,96,it)} }
